var syllables = [
    // {
    //     "name": "boing",
    //     "pitch_lo": 21,
    //     "bpm": 96
    // },
    // {
    //     "name": "chirp",
    //     "pitch_lo": 25,
    //     "bpm": 180
    // },
    // {
    //     "name": "clank",
    //     "pitch_lo": 21,
    //     "bpm": 128
    // },
    {
        "name": "dum",
        "pitch_lo": 11,
        "bpm": 137
    },
    // {
    //     "name": "honk",
    //     "pitch_lo": 20,
    //     "bpm": 85
    // },
    // {
    //     "name": "jink",
    //     "pitch_lo": 23,
    //     "bpm": 169
    // },
    {
        "name": "ping",
        "pitch_lo": 23,
        "bpm": 154
    }
    // {
    //     "name": "pop",
    //     "pitch_lo": 21,
    //     "bpm": 180
    // },
    // {
    //     "name": "quack",
    //     "pitch_lo": 16,
    //     "bpm": 156
    // },
    // {
    //     "name": "yoink",
    //     "pitch_lo": 20,
    //     "bpm": 118
    // },
    // {
    //     "name": "zoink",
    //     "pitch_lo": 21,
    //     "bpm": 146
    // },
]

module.exports = syllables;